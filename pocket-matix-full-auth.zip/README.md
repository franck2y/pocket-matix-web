# Pocket Matix Web

Web app de signaux de trading avec :
- Connexion utilisateur (Firebase Auth)
- Indicateur prédictif IA (OpenAI)
- Interface simple pour entrée manuelle + historique

## 🔧 Setup

### Installation
```bash
npm install
```

### Démarrage local
```bash
npm run dev
```

### Déploiement Vercel / Netlify
- Commande build : `npm run build`
- Dossier output : `dist`

## 🔐 Authentification Firebase
Créer un projet Firebase et activer Email/Password Auth.
Remplir le fichier `src/firebase-config.js` avec vos infos.

## 🤖 Clé API OpenAI
Créer un fichier `.env` à la racine :
```bash
VITE_OPENAI_API_KEY=sk-...
```
