import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const fetchAIIndicator = async (signal) => {
  // Simulated async AI call (replace with real API)
  return new Promise((resolve) => {
    setTimeout(() => {
      const confidence = Math.floor(Math.random() * 100);
      resolve([
        { name: "01s", confidence: confidence - 20 },
        { name: "02s", confidence: confidence - 10 },
        { name: "03s", confidence },
        { name: "04s", confidence: confidence - 15 },
        { name: "05s", confidence: confidence - 5 }
      ]);
    }, 1000);
  });
};

export default function PocketMatix() {
  const [signal, setSignal] = useState("");
  const [history, setHistory] = useState([]);
  const [aiData, setAiData] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!signal) return;
    setHistory([{ signal, date: new Date().toLocaleString() }, ...history]);
    setSignal("");
    setLoading(true);
    const data = await fetchAIIndicator(signal);
    setAiData(data);
    setLoading(false);
  };

  const redirectToPocketOption = () => {
    window.open("https://pocketoption.com", "_blank");
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      <h1 className="text-3xl font-bold mb-4 text-center">Pocket Matix Web</h1>

      <Card className="max-w-md mx-auto mb-6">
        <CardContent className="space-y-4 p-4">
          <Input
            placeholder="Entrée manuelle (UP/DOWN)"
            value={signal}
            onChange={(e) => setSignal(e.target.value)}
          />
          <Button className="w-full" onClick={handleSubmit}>
            Soumettre
          </Button>
          <Button className="w-full bg-green-600 hover:bg-green-500" onClick={redirectToPocketOption}>
            Ouvrir Pocket Option
          </Button>
        </CardContent>
      </Card>

      <Card className="max-w-md mx-auto mb-6">
        <CardContent className="p-4">
          <h2 className="text-xl font-semibold mb-2">Indicateur AI</h2>
          {loading ? (
            <p>Chargement des données AI...</p>
          ) : (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={aiData}>
                <XAxis dataKey="name" stroke="#ccc" />
                <YAxis stroke="#ccc" />
                <Tooltip />
                <Bar dataKey="confidence" fill="#4f46e5" />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      <Card className="max-w-md mx-auto">
        <CardContent className="p-4">
          <h2 className="text-xl font-semibold mb-2">Historique</h2>
          <ul className="space-y-2 text-sm">
            {history.map((item, index) => (
              <li key={index} className="border-b border-gray-700 pb-1">
                <strong>{item.signal}</strong> - {item.date}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
